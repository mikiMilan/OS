package vjezbe4;

public class Counter{
    private int count = 0;

    public synchronized void increment(){  count++;  }
    public int get() {  return count;  }
}
